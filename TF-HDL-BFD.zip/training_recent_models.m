%training recent models for comparison
clear;close all;clc;
% Load data for {'Scalogram','Spectrogram', 'HHT'}
MFO='dataset_cnn_train';
Data='train_image_net1_114'; %Scalogram
%Data='train_image_net2_114'; %Spectrogram
%Data='train_image_net3_114'; %HHT
Model_type= {'Mode1','Mode2','Mode3','Mode4','Mode5',...
    'Mode6','Mode7','Mode8','Mode9','Mode10'};
n = length(Model_type);
% Specify training and validation sets
trainRatio = 0.8;
Display=0;
A = struct();
inputSize = [32 32 3;32 32 3;96 96 3;64 64 3;...
   64 64 3;64 64 3;28 28 3;64 64 3;32 32 3;100 100 3]; % Adjusted input size
% Add progress bar
h = waitbar(0, 'Training Progress', 'Name', 'Training Progress');
for f=1:n
digitDatasetPath = fullfile('.', MFO,Data);
imds = imageDatastore(digitDatasetPath, 'IncludeSubfolders',...
           true, 'LabelSource', 'foldernames');
       Vu=[Display,f,n];
% Define CNN network
[trainedNet, A.Model_type{f}] = HMCNNnetwork(inputSize(f,:),Model_type{f},Vu,h, imds, trainRatio);
  save([Model_type{f} '.mat'], 'trainedNet');
end
save('Parameters.mat', 'A');
% Close the progress bar
close(h);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





