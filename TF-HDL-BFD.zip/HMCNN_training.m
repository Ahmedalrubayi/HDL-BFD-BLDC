clear;close all;clc;
% Load data
MFO='dataset_cnn_train';
Data_type = {'train_image_net1_114','train_image_net2_114', 'train_image_net3_114'};
Model_type= {'Scalogram','Spectrogram', 'HHT'};
n = length(Data_type);
% Specify training and validation sets
trainRatio = 0.8;
Display=1;
A = struct();
inputSize = [128 128 3 ]; % Adjusted input size
% Add progress bar
h = waitbar(0, 'Training Progress', 'Name', 'Training Progress');
for f=1:n
digitDatasetPath = fullfile('.', MFO,Data_type{f});
imds = imageDatastore(digitDatasetPath, 'IncludeSubfolders',...
           true, 'LabelSource', 'foldernames');
       Vu=[Display,f,n];
% Define CNN network
[trainedNet, A.Model_type{f}] = HMCNNnetwork(inputSize,Model_type{f},Vu,h, imds, trainRatio);
  save([Model_type{f} '.mat'], 'trainedNet');
end
save('Parameters.mat', 'A');
% Close the progress bar
close(h);



