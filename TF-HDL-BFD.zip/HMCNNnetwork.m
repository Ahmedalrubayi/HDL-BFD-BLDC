function [trainedNet, info] = HMCNNnetwork(inputSize,type,Vu,h, imds, trainRatio)
 [imdsTrain, imdsValidation] = splitEachLabel(imds, trainRatio, 'randomize');
imds_of_train_set = augmentedImageDatastore(inputSize, imdsTrain);
augmentedValidationSet = augmentedImageDatastore(inputSize, imdsValidation);
numClasses = numel(categories(imdsTrain.Labels));
 Display=Vu(1);tc=Vu(2); total_runs=Vu(3);
 switch type 
     case 'Scalogram'      
%Net1:
inputLayer = imageInputLayer(inputSize);
conv1 = convolution2dLayer(4, 8, 'Padding', 'same');
pool1 = maxPooling2dLayer(2, 'Stride', 2);
conv2 = convolution2dLayer(4, 16, 'Padding', 'same');
pool2 = maxPooling2dLayer(2, 'Stride', 2);
conv3 = convolution2dLayer(4, 32, 'Padding', 'same');
pool3 = maxPooling2dLayer(2, 'Stride', 2);
conv4 = convolution2dLayer(2, 64, 'Padding', 'same');
pool4 = maxPooling2dLayer(2, 'Stride', 2);
fc1 = fullyConnectedLayer(512);
fc2 = fullyConnectedLayer(256);
fc = fullyConnectedLayer(numClasses);
outputLayer = softmaxLayer();
classLayer = classificationLayer();
layers = [inputLayer; conv1; pool1; conv2; pool2; conv3; pool3;conv4; pool4;...
    fc1; fc2; fc; outputLayer; classLayer];
%%%%%%%%%%%%%%%%%%%%%%%%%%%5
     case 'Spectrogram'     
%%5-layers Net 2:
layers = [
    imageInputLayer(inputSize)
    convolution2dLayer(3, 32, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(3, 64, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(3, 128, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    fullyConnectedLayer(numClasses)
    softmaxLayer    
    classificationLayer
];
     case 'HHT'     
%%5-layers Net 3:
layers = [
    imageInputLayer(inputSize)
    convolution2dLayer(3, 8, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(3, 32, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(3, 64, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(3, 128, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)

    fullyConnectedLayer(numClasses)
    softmaxLayer    
    classificationLayer
];

 case 'Mode1'  % compare with 'Mode1' to 'Mode10' 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the input size inputSize = [32 32 1]

 case 'Mode2' 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 case 'Mode3' 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the input size inputSize = [96 96 1];

  case 'Mode4' 
 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Define the network architecture

  case 'Mode5' 
  % Define the layers Duy-Tang Hoang 2019

  case 'Mode6'  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  case 'Mode7'

% % Define the layers [28 28]

  case 'Mode8'

 case 'Mode9'

 end

 %% Specify training options
 miniBatchSize = 64; % Set your desired mini-batch size
 MaxEpochs=50;
   options = trainingOptions('adam', ...
        'InitialLearnRate', 0.0001, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropFactor', 0.1, ...
        'LearnRateDropPeriod', 10, ...
        'MaxEpochs', MaxEpochs, ...
        'MiniBatchSize', miniBatchSize, ...
        'Shuffle', 'every-epoch', ...
        'ValidationData', augmentedValidationSet, ...
        'ValidationFrequency', 100, ...
        'ValidationPatience', 5, ...
        'Verbose', true, ...
        'Plots', 'none', ...  % On:'training-progress'
        'OutputFcn', @(X) myTrainingProgress(X, MaxEpochs,tc, total_runs, h));

  %% Train the CNN network
[trainedNet, info] = trainNetwork(imds_of_train_set,layers,options);

%% Display loss and accuracy
if Display==1
color = 'bgrcmykbgrb'; % Drawing color
symbol = 'o*sdph+xo*sd'; % Drawing line type
figure('name',[type,'-Accuracy']);grid on; hold on ;
plot(1:length(info.TrainingAccuracy),info.TrainingAccuracy, [color(1), '-', symbol(1)]);
plot(1:length(info.ValidationAccuracy),info.ValidationAccuracy, [color(2), '-', symbol(2)]);
xlabel('Iteration');
ylabel('Accuracy');
legend('Training Accuracy','Validation Accuracy');
title([type,'-Accuracy']);
figure('name',[type ,'-Loss']);grid on; hold on ;
plot(1:length(info.TrainingLoss),info.TrainingLoss, [color(2), '-', symbol(2)]);
plot(1:length(info.ValidationLoss),info.ValidationLoss, [color(3), '-', symbol(3)]);
xlabel('Iteration');
ylabel('Loss');
legend('Training Loss','Validation Loss');
title([type ,'-Loss']);

%% Validation
YPred = classify(trainedNet,augmentedValidationSet);
YValidation = imdsValidation.Labels;
accuracy = sum(YPred == YValidation)/numel(YValidation);
disp([type,'-Accuracy =' num2str(accuracy)]);
end

end

% Custom progress update function
function stop = myTrainingProgress(X,MaxEpochs, current_run, total_runs, h)
    % Calculate the overall progress
    overall_progress = (current_run - 1 + X.Epoch /MaxEpochs )/ total_runs;
    waitbar(overall_progress, h, sprintf('Training Progress: %.1f%%', overall_progress * 100));
    stop = false;
end


