clc;
clear;
close all; %Model_type= {'Scalogram','Spectrogram', 'HHT'};{'net1','net2','net3'}
MFO = 'dataset_cnn_test';
Data_type = {'test_image_net1_144', 'test_image_net2_144','test_image_net3_144'};
%Net_type = {'Scalogram', 'Spectrogram', 'HHT'};  %
Net_type = {'net1','net2','net3'};
n = length(Data_type);n2 = length(Net_type);
number_of_each_train_test = 1600;
inputSize = [64 64 3];MSE=zeros(n,1);
M=cell(n2,1);A=cell(n2,1);
% Initialize the waitbar
wb = waitbar(0, 'Processing Testing Data...', 'Name', 'Loading');
for f = 1:n
    folderName = fullfile('.', MFO, Data_type{f});
%% Load data
imds1 = imageDatastore(folderName, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
[imdstest1, ~] = splitEachLabel(imds1, ...
    number_of_each_train_test, 'randomize');
imds_of_Test_set1 = augmentedImageDatastore(inputSize, imdstest1);
Count_of_Label = countEachLabel(imdstest1);
Label= size(Count_of_Label,1);
N= Count_of_Label.Count(1);
% Perform classification on the testing data
YTest = imdstest1.Labels;
Net=load(Net_type{f});
Net=Net.trainedNet;
YPred = classify(Net, imds_of_Test_set1);
MSE(f)= mean((double(YPred ) - double(YTest )).^2);
M{f}=YPred;A{f}=YTest; %Ylabels1
 % Update waitbar
        waitbar(f/ n, wb, sprintf('Processing Data... %.0f%%', f/ n * 100));
end
%% Evaluate the CNN network
if MSE(1) < MSE(2) 
        YPred_test= M{1};
else
    if MSE(2) < MSE(3)
        YPred_test = M{2};
    else
        YPred_test = M{3};
    end
end
% Close the waitbargrp2idx(A{1});
close(wb);
YTest=A{1};
%% Evaluate the CNN network by calculating  evaluation metrics
% Plot the bar chart
pr=100;
metricsNames = {'Accuracy', 'Precision', 'Sensitivity', 'Specificity', 'F-Measure'};
%classNames = {'Ball Rolling Fault', 'Inner Race Fault', 'Normal', 'Outer Race Fault'};
classNames = {'BA', 'IN', 'NO', 'OT'};
% Calculate evaluation metrics
% Plot confusion matrix
% Calculate evaluation metrics
accuracy = sum(YPred_test == YTest) / numel(YTest);
confMat = confusionmat(YTest, YPred_test);
confMatp=confMat*100/N;
numClasses = size(confMat, 1);
precision = zeros(numClasses, 1);
sensitivity = zeros(numClasses, 1);
specificity = zeros(numClasses, 1);
fMeasure = zeros(numClasses, 1);
for i = 1:numClasses
    TP = confMat(i, i);
    FP = sum(confMat(:, i)) - TP;
    FN = sum(confMat(i, :)) - TP;
    TN = sum(confMat(:)) - TP - FP - FN;

    precision(i) = TP / (TP + FP);
    sensitivity(i) = TP / (TP + FN);
    specificity(i) = TN / (TN + FP);
    fMeasure(i) = (2 * precision(i) * sensitivity(i)) / (precision(i) + sensitivity(i));
end
metricsValues = [accuracy, mean(precision), mean(sensitivity), mean(specificity), mean(fMeasure)];
figure;
bar(metricsValues);
xticks(1:numel(metricsNames));
xticklabels(metricsNames);
ylabel('Metric Value');
title('Evaluation Metrics');
% Calculate the loss (mean squared error)
loss = mean((double(YPred_test) - double(YTest)).^2);
fprintf('Evaluation Metrics:\n');
fprintf('-------------------\n');
fprintf('Class\tPrecision\tSensitivity\tSpecificity\tF-Measure\n');
fprintf('--------------------------------------------------------------------------\n');

for i = 1:numClasses
    fprintf('%s\t\t%.2f\t\t%.2f%%\t\t%.2f%%\t\t%.2f\n', ...
        classNames{i}, precision(i), sensitivity(i), ...
        specificity(i), fMeasure(i));
end
fprintf('--------------------------------------------------------------------------\n');
% Display the results
disp(['Accuracy: ' num2str(accuracy*100)]);
disp(['Loss: ' num2str(loss)]);
disp(['True Positive: ' num2str(TP')]);
disp(['False Positive: ' num2str(FP)]);
disp(['False Negative: ' num2str(FN)]);
disp(['True Negative: ' num2str(TN)]);

% plotconfusion(YTest, YPred_test);
% set(gca,'xticklabel',{'BA', 'IN', 'NO', 'OT','Total True/Loss'})
% set(gca,'YTickLabel',{'BA', 'IN', 'NO', 'OT','True/Loss'})
% ylabel('Predicted Label');
% xlabel('True Label');
% Define a custom colormap with shades of blue and white
customColormap = [1 1 1; 1 1 1;0.5 0.5 1]; % You can adjust the shades of blue as needed
% Plot confusion matrix heatmap with the custom colormap
figure('name', 'confusion matrix');
heatmap({'BA', 'IN', 'NO', 'OT'},...
    {'BA', 'IN', 'NO', 'OT'}, confMat, 'Colormap', customColormap, 'ColorbarVisible', 'off');
xlabel('Predicted Labels');
ylabel('True Labels');


disp(num2str(confMatp));

figure('name','Evaluation Metrics')
subplot(2, 2, 1)
bar(precision'*pr)
title('Precision')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')

subplot(2, 2, 2)
bar(sensitivity'*pr)
title('Sensitivity')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')

subplot(2, 2, 3)
bar(specificity'*pr)
title('Specificity')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')

subplot(2, 2, 4)
bar(fMeasure'*pr)
title('F-measure')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')


