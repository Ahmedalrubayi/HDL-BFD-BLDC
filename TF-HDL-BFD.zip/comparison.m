clc;
clear;
close all;
MFO = 'dataset_cnn_test';
%Scalogram:Net1:%Spectrogram :Net2: HHTNet3:
%Netx_ADCNN; Netx_Duy ;Netx_Long_Wen
% The selected recent models for comparison:'Mode2','Mode5','Mode6'
net1=load('Net1_Long_Wen');
net1=net1.trainedNet;
net2=load('Net2_Long_Wen');
net2=net2.trainedNet;
net3=load('Net3_Long_Wen');
net3=net3.trainedNet;
iSize = [32 32 3;64 64 3;64 64 3]; % Adjusted input size
inputSize = iSize(1,:);
%% Load data
imds1 = imageDatastore(fullfile(MFO,'test_image_net1_144'), 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
imds2 = imageDatastore(fullfile(MFO,'test_image_net2_144'), 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
imds3 = imageDatastore(fullfile(MFO,'test_image_net3_144'), 'IncludeSubfolders', true, 'LabelSource', 'foldernames');

%% Classify testing set using the trained CNN network
number_of_each_train_test = 1600;
[imdstest1, ~] = splitEachLabel(imds1, ...
    number_of_each_train_test, 'randomize');
[imdstest2, ~] = splitEachLabel(imds2, ...
    number_of_each_train_test, 'randomize');
[imdstest3, ~] = splitEachLabel(imds3, ...
    number_of_each_train_test, 'randomize');

YTest = imdstest1.Labels;
imds_of_Test_set1 = augmentedImageDatastore(inputSize, imdstest1);
imds_of_Test_set2 = augmentedImageDatastore(inputSize, imdstest2);
imds_of_Test_set3 = augmentedImageDatastore(inputSize, imdstest3);
% Perform classification on the testing data
YPred1 = classify(net1, imds_of_Test_set1);
YPred2 = classify(net2, imds_of_Test_set2);
YPred3 = classify(net3, imds_of_Test_set3);

%% Evaluate the CNN network YPred1: Scalogram:YPred2:Spectrogram :YPred3: HHT
 YPred_test= YPred3;
%% Evaluate the CNN network by calculating the accuracy of the testing set
% Calculate evaluation metrics
% Plot confusion matrix
% Calculate evaluation metrics
accuracy = sum(YPred_test == YTest) / numel(YTest); % Accuracy
C = confusionmat(YTest, YPred_test); % Confusion matrix
TP = diag(C); % True Positive
FP = sum(C) - TP'; % False Positive
FN = sum(C') - TP'; % False Negative
TN = sum(C(:)) - TP' - FP - FN; % True Negative
precision = diag(C) ./ sum(C, 1)'; % Precision
recall = diag(C) ./ sum(C, 2); % Sensitivity
fMeasure = 2 * (precision .* recall) ./ (precision + recall); % F-measure
specificity = TN ./ (TN + FP); % Specificity or True Negative Rate (TNR)
pr=100;
% Calculate the loss (mean squared error)
loss = mean((double(YPred_test) - double(YTest)).^2);
% Display the results
disp(['Accuracy: ' num2str(accuracy*pr)]);
disp('Confusion Matrix:');
disp(C);
disp(['Precision: ' num2str(mean(precision')*pr)]);
disp(['Sensitivity: ' num2str(mean(recall')*pr)]);
disp(['Specificity: ' num2str(mean(specificity)*pr)]);
disp(['F-measure: ' num2str(mean(fMeasure')*pr)]);
disp(['Loss: ' num2str(loss)]);

disp(['True Positive: ' num2str(TP')]);
disp(['False Positive: ' num2str(FP)]);
disp(['False Negative: ' num2str(FN)]);
disp(['True Negative: ' num2str(TN)]);
% plotconfusion(YTest,YPred_test)
% set(gca,'xticklabel',{'BA', 'IN', 'NO', 'OT','Total True/Loss'})
% set(gca,'YTickLabel',{'BA', 'IN', 'NO', 'OT','True/Loss'})
% ylabel('Predicted Label');
% xlabel('True Label');
% Plot confusion matrix heatmap with the custom colormap
classNames = {'BA', 'IN', 'NO', 'OT'};
figure('name', 'confusion matrix');
customColormap = [1 1 1; 1 1 1;0.5 0.5 1]; % You can adjust the shades of blue as needed
heatmap(classNames,classNames, C, 'Colormap', customColormap, 'ColorbarVisible', 'off');
xlabel('Predicted Labels');
ylabel('True Labels');

figure('name','Evaluation Metrics')

subplot(2, 2, 1)
bar(precision'*pr)
title('Precision')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')

subplot(2, 2, 2)
bar(recall'*pr)
title('Sensitivity')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')

subplot(2, 2, 3)
bar(specificity'*pr)
title('Specificity')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')
subplot(2, 2, 4)
bar(fMeasure'*pr)
title('F-measure')
set(gca,'xticklabel',classNames)
xtickangle(45)
ylabel('Value (%)')
